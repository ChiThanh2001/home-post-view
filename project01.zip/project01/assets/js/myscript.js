//Phân tích Bài toán lúc này: Nhấn vào BUTTON > thay đổi P 
// 1. Xác định các đối tượng chịu tác động
let txtFruit        = document.getElementById("txtFruit");
let btnShowFruit    = document.getElementById("btnShowFruit");
let lblTitle        = document.getElementById("lblTitle");
// let imgContainer    = document.getElementById("imgContainer");
let imgItem = document.getElementById("imgItem");
let btnAddMore = document.getElementById("btnAddMore");
let imgContainer = document.getElementById("imgContainer");
// 2. Xử lý: Bắt sự kiện (Có nhiều cách)
btnShowFruit.addEventListener("click", hamGiDo);

// 3. Hàm xử lý sự kiện:
function hamGiDo(){
    let listFruits = ['banana','orange','lemon','strawberry','watermelon'];
    let fruit = txtFruit.value;

    // Can hoc va ren luyen tu duy Lap trinh truoc do
    if(fruit == ''){
        alert('You must input a fruit');
    }else{
        let result = false;
        for(let i=0; i<listFruits.length; i++){
            if(fruit == listFruits[i]){
                result = true;
                break;
            }
        }
        if(result == true){
            lblTitle.textContent = fruit;
            // imgContainer.innerHTML='<img src="assets/images/'+fruit+'.jpg" alt="">';
            imgItem.src = 'assets/images/'+fruit+'.jpg';
        }else{
            alert("Fruit is not exited")
        }
    }


}

btnAddMore.addEventListener("click", function(){
    let newElement = document.createElement("img");
    newElement.src = "assets/images/strawberry.jpg";

    imgContainer.appendChild(newElement);
})

